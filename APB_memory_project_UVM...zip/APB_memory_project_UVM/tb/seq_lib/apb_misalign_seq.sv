class apb_misalign_seq extends apb_base_seq;
  `uvm_object_utils(apb_misalign_seq)

  function new(string name = "apb_misalign_seq");
    super.new(name);
  endfunction

  virtual task body();

    // Misaligned writes
    write_one(32'h0000_0004, 64'hAAAA_AAAA_AAAA_AAAA, 8'hFF);
    write_one(32'h0000_0014, 64'hBBBB_BBBB_BBBB_BBBB, 8'hFF);
    write_one(32'h0000_001C, 64'hCCCC_CCCC_CCCC_CCCC, 8'hFF);
    write_one(32'h0000_0002, 64'hDDDD_DDDD_DDDD_DDDD, 8'hFF);
    write_one(32'h0000_0001, 64'hEEEE_EEEE_EEEE_EEEE, 8'hFF);
    write_one(32'h0000_0007, 64'hFFFF_FFFF_FFFF_FFFF, 8'hFF);

    // Misaligned reads
    read_one(32'h0000_0004);
    read_one(32'h0000_0014);
    read_one(32'h0000_001C);
    read_one(32'h0000_0002);
    read_one(32'h0000_0001);
    read_one(32'h0000_0007);

  endtask

endclass
