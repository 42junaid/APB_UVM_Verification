class apb_random_seq extends apb_base_seq;
  `uvm_object_utils(apb_random_seq)

  function new(string name = "apb_random_seq");
    super.new(name);
  endfunction

  virtual task body();
    apb_seq_item req;

    repeat (2000) begin
      req = apb_seq_item::type_id::create("req");
      start_item(req);
      if (!req.randomize())
        `uvm_error("RAND_SEQ", "Randomization failed")
      finish_item(req);
    end

  endtask

endclass
