// ============================================================
// FILE: seq_lib/apb_base_seq.sv
// Base sequence ? all sequences extend this
// Contains: helper tasks for write and read
// ============================================================
class apb_base_seq extends uvm_sequence #(apb_seq_item);
  `uvm_object_utils(apb_base_seq)

  function new(string name = "apb_base_seq");
    super.new(name);
  endfunction

  // ============================================================
  // Helper Task 1: Write
  // ============================================================
  virtual task write_one(bit [31:0] addr, bit [63:0] data, bit [7:0] strb);
    apb_seq_item req;
    req = apb_seq_item::type_id::create("req");
    start_item(req);
    req.write = 1'b1;
    req.addr  = addr;
    req.wdata = data;
    req.strb  = strb;
    `uvm_info("SEQ", $sformatf("WRITE: addr=%0h data=%0h strb=%0h",
              addr, data, strb), UVM_LOW)
    finish_item(req);
  endtask

  // ============================================================
  // Helper Task 2: Read
  // ============================================================
  virtual task read_one(bit [31:0] addr);
    apb_seq_item req;
    req = apb_seq_item::type_id::create("req");
    start_item(req);
    req.write = 1'b0;
    req.addr  = addr;
    req.wdata = '0;
    req.strb  = '0;
    `uvm_info("SEQ", $sformatf("READ:  addr=%0h", addr), UVM_LOW)
    finish_item(req);
  endtask

endclass
