class apb_pstrb_seq extends apb_base_seq;
  `uvm_object_utils(apb_pstrb_seq)

  function new(string name = "apb_pstrb_seq");
    super.new(name);
  endfunction

  virtual task body();

    // Initialize memory with all AA
    pstrb_test(32'h0000_0050, 64'hAAAA_AAAA_AAAA_AAAA, 8'hFF);

    // Update byte by byte ? each with different data
    pstrb_test(32'h0000_0050, 64'h1111_1111_1111_1111, 8'h01);
    pstrb_test(32'h0000_0050, 64'h2222_2222_2222_2222, 8'h02);
    pstrb_test(32'h0000_0050, 64'h3333_3333_3333_3333, 8'h04);
    pstrb_test(32'h0000_0050, 64'h4444_4444_4444_4444, 8'h08);
    pstrb_test(32'h0000_0050, 64'h5555_5555_5555_5555, 8'h10);
    pstrb_test(32'h0000_0050, 64'h6666_6666_6666_6666, 8'h20);
    pstrb_test(32'h0000_0050, 64'h7777_7777_7777_7777, 8'h40);
    pstrb_test(32'h0000_0050, 64'h8888_8888_8888_8888, 8'h80);
    pstrb_test(32'h0000_0050, 64'h1111_1111_1111_1111, 8'h0F);
pstrb_test(32'h0000_0050, 64'h2222_2222_2222_2222, 8'hF0);

  endtask

  task pstrb_test(bit [31:0] addr, bit [63:0] data, bit [7:0] strb);
    write_one(addr, data, strb);
    read_one(addr);
  endtask

endclass
