class apb_boundary_seq extends apb_base_seq;
  `uvm_object_utils(apb_boundary_seq)

  function new(string name = "apb_boundary_seq");
    super.new(name);
  endfunction

  virtual task body();

    // First valid addresses
    write_one(32'h0000_0000, 64'hAAAA_AAAA_AAAA_AAAA, 8'hFF);
    read_one(32'h0000_0000);

    write_one(32'h0000_0008, 64'hBBBB_BBBB_BBBB_BBBB, 8'hFF);
    read_one(32'h0000_0008);

    // Near boundary
    write_one(32'h0000_FF00, 64'hCCCC_CCCC_CCCC_CCCC, 8'hFF);
    read_one(32'h0000_FF00);

    write_one(32'h0000_FF10, 64'hDDDD_DDDD_DDDD_DDDD, 8'hFF);
    read_one(32'h0000_FF10);

    // Last valid address (64KB - 8 = 0xFFF8)
    write_one(32'h0000_FFF8, 64'hEEEE_EEEE_EEEE_EEEE, 8'hFF);
    read_one(32'h0000_FFF8);

    // First invalid (64KB)
    write_one(32'h0001_0000, 64'hFFFF_FFFF_FFFF_FFFF, 8'hFF);
    read_one(32'h0001_0000);

    // Misaligned at boundary
    write_one(32'h0000_FFFC, 64'h1234_5678_9ABC_DEF0, 8'hFF);
    read_one(32'h0000_FFFC);

  endtask

endclass
