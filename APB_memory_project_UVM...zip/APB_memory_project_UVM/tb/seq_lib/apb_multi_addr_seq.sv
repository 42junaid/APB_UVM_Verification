// ============================================================
// FILE: seq_lib/apb_multi_addr_seq.sv
// Multiple address write + read
// ============================================================
class apb_multi_addr_seq extends apb_base_seq;
  `uvm_object_utils(apb_multi_addr_seq)

  function new(string name = "apb_multi_addr_seq");
    super.new(name);
  endfunction

  virtual task body();
    // ---------- 4 WRITEs ----------
    write_one(32'h0000_0010, 64'h1111_1111_1111_1111, 8'hFF);
    write_one(32'h0000_0020, 64'h2222_2222_2222_2222, 8'hFF);
    write_one(32'h0000_0030, 64'h3333_3333_3333_3333, 8'hFF);
    write_one(32'h0000_0040, 64'h4444_4444_4444_4444, 8'hFF);

    // ---------- 4 READs ----------
    read_one(32'h0000_0010);
    read_one(32'h0000_0020);
    read_one(32'h0000_0030);
    read_one(32'h0000_0040);
  endtask

endclass
