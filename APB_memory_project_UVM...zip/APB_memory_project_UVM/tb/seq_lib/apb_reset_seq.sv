class apb_reset_seq extends apb_base_seq;
  `uvm_object_utils(apb_reset_seq)

  function new(string name = "apb_reset_seq");
    super.new(name);
  endfunction

  virtual task body();

    // Normal transfers before reset
    write_one(32'h0000_0010, 64'hAAAA_AAAA_AAAA_AAAA, 8'hFF);
    read_one(32'h0000_0010);

    write_one(32'h0000_0020, 64'hBBBB_BBBB_BBBB_BBBB, 8'hFF);
    read_one(32'h0000_0020);

    // Normal transfers after reset (reset is in tb_top, already released)
    write_one(32'h0000_0030, 64'hCCCC_CCCC_CCCC_CCCC, 8'hFF);
    read_one(32'h0000_0030);

    write_one(32'h0000_0040, 64'hDDDD_DDDD_DDDD_DDDD, 8'hFF);
    read_one(32'h0000_0040);

  endtask

endclass
