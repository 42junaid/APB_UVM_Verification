class apb_oob_seq extends apb_base_seq;
  `uvm_object_utils(apb_oob_seq)

  function new(string name = "apb_oob_seq");
    super.new(name);
  endfunction

  virtual task body();

    // Out-of-bounds writes
    write_one(32'h0001_0000, 64'hAAAA_AAAA_AAAA_AAAA, 8'hFF);
    write_one(32'h0001_0008, 64'hBBBB_BBBB_BBBB_BBBB, 8'hFF);
    write_one(32'h0002_0000, 64'hCCCC_CCCC_CCCC_CCCC, 8'hFF);
    write_one(32'h0008_0000, 64'hDDDD_DDDD_DDDD_DDDD, 8'hFF);
    write_one(32'h1000_0000, 64'hEEEE_EEEE_EEEE_EEEE, 8'hFF);
    write_one(32'h8000_0000, 64'hFFFF_FFFF_FFFF_FFFF, 8'hFF);
    write_one(32'hFFFF_FFF8, 64'h1234_5678_9ABC_DEF0, 8'hFF);

    // Out-of-bounds reads
    read_one(32'h0001_0000);
    read_one(32'h0001_0008);
    read_one(32'h0002_0000);
    read_one(32'h0008_0000);
    read_one(32'h1000_0000);
    read_one(32'h8000_0000);
    read_one(32'hFFFF_FFF8);

  endtask

endclass
