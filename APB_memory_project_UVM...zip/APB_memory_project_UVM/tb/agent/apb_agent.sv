class apb_agent extends uvm_agent;
`uvm_component_utils(apb_agent)
 
 function new(string path = "apb_agent", uvm_component parent);
super.new(path,parent);
endfunction

apb_monitor monitor;
apb_driver driver;
apb_sequencer sequencer;

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    
    monitor = apb_monitor::type_id::create("monitor", this);

    //creating driver and sequencer only for ACTIVE agent
    if(get_is_active() == UVM_ACTIVE) begin
      driver    = apb_driver::type_id::create("driver", this);
      sequencer = apb_sequencer::type_id::create("sequencer", this);
    end
  endfunction : build_phase
  
  function void connect_phase(uvm_phase phase);
    if(get_is_active() == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
  endfunction : connect_phase
endclass
