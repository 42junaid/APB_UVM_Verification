class apb_driver extends uvm_driver #(apb_seq_item);
  `uvm_component_utils(apb_driver)

  virtual apb_interface aif;

  function new(string path = "apb_driver", uvm_component parent = null);
    super.new(path, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual apb_interface)::get(null, "uvm_test_top", "interface", aif)) begin
      `uvm_error("driver", "unable to access interface");
end
    else begin
      `uvm_info("driver", "interface is our access", UVM_LOW);
end
  endfunction

  virtual task run_phase(uvm_phase phase);
    apb_seq_item req;
    forever begin
      seq_item_port.get_next_item(req);
      `uvm_info("DRV", $sformatf("Received: write=%0d addr=%0h data=%0h strb=%0h",
                req.write, req.addr, req.wdata, req.strb), UVM_LOW)
      drive_apb(req);
      seq_item_port.item_done();
    end
  endtask

  task drive_apb(apb_seq_item req);
    // ---------- SETUP ----------
    @(posedge aif.PCLK);
    aif.PSELx   <= 1'b1;
    aif.PENABLE <= 1'b0;
    aif.PWRITE  <= req.write;
    aif.PADDR   <= req.addr;
    aif.PWDATA  <= req.wdata;
    aif.PSTRB   <= req.strb;
    `uvm_info("DRV", "SETUP phase", UVM_LOW)

    // ---------- ACCESS ----------
    @(posedge aif.PCLK);
    aif.PENABLE <= 1'b1;
    `uvm_info("DRV", "ACCESS phase", UVM_LOW)

    // ---------- Wait for PREADY ----------
    wait(aif.PREADY == 1'b1);
    `uvm_info("DRV", "PREADY received", UVM_LOW)
    @(posedge aif.PCLK);

    // ---------- Deassert ----------
    aif.PSELx   <= 1'b0;
    aif.PENABLE <= 1'b0;
    aif.PWRITE  <= 1'b0;
    aif.PADDR   <= '0;
    aif.PWDATA  <= '0;
    aif.PSTRB   <= '0;
    `uvm_info("DRV", "Transfer complete", UVM_LOW)
  endtask

endclass
