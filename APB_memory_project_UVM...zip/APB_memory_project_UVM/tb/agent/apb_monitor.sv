class apb_monitor extends uvm_monitor;
  `uvm_component_utils(apb_monitor)

  virtual apb_interface vif1;
  uvm_analysis_port #(apb_seq_item) item_collected_port;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    item_collected_port = new("item_collected_port", this);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    `uvm_info("MON", "Build Phase Executed", UVM_NONE)
    if (!uvm_config_db#(virtual apb_interface)::get(null, "uvm_test_top", "interface", vif1)) begin
      `uvm_error("MON", "Unable to access Interface");
end
    else begin
      `uvm_info("MON", "Interface connected", UVM_NONE);
end
  endfunction

  // ? run_phase add ? bus sample karo
  virtual task run_phase(uvm_phase phase);
    `uvm_info("MON", "Run Phase Executed", UVM_NONE)
    forever begin
      @(posedge vif1.PCLK);

      // ? Transfer complete condition
      if (vif1.PSELx == 1'b1 && vif1.PENABLE == 1'b1 && vif1.PREADY == 1'b1) begin

        apb_seq_item tr = apb_seq_item::type_id::create("tr");

        // ? Bus se data capture karo
        tr.write   = vif1.PWRITE;
        tr.addr    = vif1.PADDR;
        tr.wdata   = vif1.PWDATA;
        tr.strb    = vif1.PSTRB;
        tr.rdata   = vif1.PRDATA;
        tr.pslverr = vif1.PSLVERR;

        `uvm_info("MON", $sformatf("Sampled: write=%0d addr=%0h wdata=%0h rdata=%0h",
                  tr.write, tr.addr, tr.wdata, tr.rdata), UVM_LOW)

        // ? Scoreboard ko bhejo
        item_collected_port.write(tr);
      end
    end
  endtask

endclass
