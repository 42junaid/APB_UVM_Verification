class apb_misalign_test extends apb_model_base_test;
  `uvm_component_utils(apb_misalign_test)

  apb_misalign_seq seq;

  function new(string name = "apb_misalign_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    seq = apb_misalign_seq::type_id::create("seq");
  endfunction

  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    wait(vif.PRESETn == 1'b1);
    repeat(2) @(posedge vif.PCLK);
    seq.start(environment.agent.sequencer);
    phase.drop_objection(this);
    phase.phase_done.set_drain_time(this, 50);
  endtask

endclass
