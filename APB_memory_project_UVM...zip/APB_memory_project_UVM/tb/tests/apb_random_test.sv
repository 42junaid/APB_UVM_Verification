class apb_random_test extends apb_model_base_test;
  `uvm_component_utils(apb_random_test)

  apb_random_seq seq;

  function new(string name = "apb_random_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    seq = apb_random_seq::type_id::create("seq");

    // ? Timeout barhao ? is test ke liye
    uvm_top.set_timeout(5_000_000, 0);
  endfunction

  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    wait(vif.PRESETn == 1'b1);
    repeat(2) @(posedge vif.PCLK);
    seq.start(environment.agent.sequencer);
    phase.drop_objection(this);
    phase.phase_done.set_drain_time(this, 50);
  endtask

endclass
