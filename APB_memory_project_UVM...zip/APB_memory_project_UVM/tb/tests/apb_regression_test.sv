class apb_regression_test extends apb_model_base_test;
  `uvm_component_utils(apb_regression_test)

  apb_multi_addr_seq  seq_multi;
  apb_pstrb_seq       seq_pstrb;
  apb_misalign_seq    seq_misalign;
  apb_oob_seq         seq_oob;
  apb_boundary_seq    seq_boundary;
  apb_reset_seq       seq_reset;
  apb_random_seq      seq_random;

  function new(string name = "apb_regression_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    uvm_top.set_timeout(10_000_000, 0);

    seq_multi    = apb_multi_addr_seq::type_id::create("seq_multi");
    seq_pstrb    = apb_pstrb_seq::type_id::create("seq_pstrb");
    seq_misalign = apb_misalign_seq::type_id::create("seq_misalign");
    seq_oob      = apb_oob_seq::type_id::create("seq_oob");
    seq_boundary = apb_boundary_seq::type_id::create("seq_boundary");
    seq_reset    = apb_reset_seq::type_id::create("seq_reset");
    seq_random   = apb_random_seq::type_id::create("seq_random");
  endfunction

  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    wait(vif.PRESETn == 1'b1);
    repeat(2) @(posedge vif.PCLK);

    `uvm_info("REG", "===== multi_addr_seq =====", UVM_LOW)
    seq_multi.start(environment.agent.sequencer);

    `uvm_info("REG", "===== pstrb_seq =====", UVM_LOW)
    seq_pstrb.start(environment.agent.sequencer);

    `uvm_info("REG", "===== misalign_seq =====", UVM_LOW)
    seq_misalign.start(environment.agent.sequencer);

    `uvm_info("REG", "===== oob_seq =====", UVM_LOW)
    seq_oob.start(environment.agent.sequencer);

    `uvm_info("REG", "===== boundary_seq =====", UVM_LOW)
    seq_boundary.start(environment.agent.sequencer);

    `uvm_info("REG", "===== reset_seq =====", UVM_LOW)
    seq_reset.start(environment.agent.sequencer);

    `uvm_info("REG", "===== random_seq =====", UVM_LOW)
    seq_random.start(environment.agent.sequencer);

    `uvm_info("REG", "===== Regression complete =====", UVM_LOW)

    phase.drop_objection(this);
    phase.phase_done.set_drain_time(this, 50);
  endtask

endclass
