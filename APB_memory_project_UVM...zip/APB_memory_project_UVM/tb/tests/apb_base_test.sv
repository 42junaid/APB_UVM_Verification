// ============================================================
// FILE: tests/apb_base_test.sv
// Base test ? all tests extend this
// NO run_phase here (extended tests will have it)
// ============================================================
class apb_model_base_test extends uvm_test;
  `uvm_component_utils(apb_model_base_test)

  apb_env environment;
  virtual apb_interface vif;

  function new(string name = "apb_model_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    environment = apb_env::type_id::create("environment", this);
    if (!uvm_config_db#(virtual apb_interface)::get(this, "", "interface", vif))
      `uvm_fatal("TEST", "Unable to get interface")
  endfunction

  virtual function void end_of_elaboration();
    print();
  endfunction

  function void report_phase(uvm_phase phase);
    uvm_report_server svr;
    super.report_phase(phase);
    svr = uvm_report_server::get_server();
    if (svr.get_severity_count(UVM_FATAL) + svr.get_severity_count(UVM_ERROR) > 0) begin
      `uvm_info(get_type_name(), "---------------------------------------", UVM_NONE)
      `uvm_info(get_type_name(), "----            TEST FAIL          ----", UVM_NONE)
      `uvm_info(get_type_name(), "---------------------------------------", UVM_NONE)
    end
    else begin
      `uvm_info(get_type_name(), "---------------------------------------", UVM_NONE)
      `uvm_info(get_type_name(), "----           TEST PASS           ----", UVM_NONE)
      `uvm_info(get_type_name(), "---------------------------------------", UVM_NONE)
    end
  endfunction

endclass
