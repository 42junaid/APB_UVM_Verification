// ============================================================
// FILE: testbench_top.sv
// Top module ? DUT + Interface + UVM config
// ============================================================
module tb_top;
  logic PCLK;

  // Interface
  apb_interface vif (PCLK);

  // Clock
  initial begin
    PCLK = 0;
    forever #5 PCLK = ~PCLK;
  end

  // Reset
  initial begin
    vif.PRESETn = 0;
    vif.PSELx   = 0;
    vif.PENABLE = 0;
    vif.PWRITE  = 0;
    vif.PADDR   = '0;
    vif.PWDATA  = '0;
    vif.PSTRB   = '0;
    repeat(3) @(posedge PCLK);
    vif.PRESETn = 1;
    $display("[TB] Reset released at time %0t", $time);
  end

  // DUT ? apb_wrapper
  apb_wrapper dut (
    .PCLK    (PCLK),
    .PRESETn (vif.PRESETn),
    .PSELx   (vif.PSELx),
    .PENABLE (vif.PENABLE),
    .PWRITE  (vif.PWRITE),
    .PWDATA  (vif.PWDATA),
    .PSTRB   (vif.PSTRB),
    .PADDR   (vif.PADDR),
    .PRDATA  (vif.PRDATA),
    .PREADY  (vif.PREADY),
    .PSLVERR (vif.PSLVERR)
  );

  // UVM config + waves
  initial begin
    uvm_config_db #(virtual apb_interface)::set(null, "uvm_test_top", "interface", vif);
    $vcdplusfile("waveform.vpd");
    $vcdpluson;
  end

  // Run test ? command line se naam aayega
  initial begin
    run_test();
  end
endmodule
