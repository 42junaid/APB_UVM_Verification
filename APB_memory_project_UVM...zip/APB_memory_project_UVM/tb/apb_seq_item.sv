class apb_seq_item extends uvm_sequence_item;

  rand bit          write;
  rand bit [31:0]   addr;
  rand bit [63:0]   wdata;
  rand bit [7:0]    strb;

  logic [63:0]      rdata;
  logic             pslverr;

  // ============================================================
  // Constraints
  // ============================================================
  
  // Address: valid range, 8-byte aligned
  constraint c_addr {
    addr inside {[32'h0000_0000 : 32'h0000_FFF8]};
    addr % 8 == 0;
  }

  // PSTRB: all 256 combos ? with weightage
constraint c_strb {
  strb dist {
    8'hFF         := 5,     // Full word
    8'h00         := 15,    // Nothing (badhao: 2 ? 15)
    [8'h01:8'hFE] := 50     // All others
  };
}

  // ============================================================
  // UVM Factory Registration
  // ============================================================
  `uvm_object_utils_begin(apb_seq_item)
    `uvm_field_int(write,   UVM_ALL_ON)
    `uvm_field_int(addr,    UVM_ALL_ON)
    `uvm_field_int(wdata,   UVM_ALL_ON)
    `uvm_field_int(strb,    UVM_ALL_ON)
    `uvm_field_int(rdata,   UVM_ALL_ON)
    `uvm_field_int(pslverr, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "apb_seq_item");
    super.new(name);
  endfunction

endclass
