interface apb_interface(input logic PCLK);

    // APB signals
    logic        PRESETn;
    logic        PSELx;
    logic        PENABLE;
    logic        PWRITE;

    logic [31:0] PADDR;
    logic [63:0] PWDATA;
    logic [7:0]  PSTRB;

    logic [63:0] PRDATA;
    logic        PREADY;
    logic        PSLVERR;


    // Clocking block used by the driver
  /*  clocking cb @(posedge PCLK);

        default input #1step output #1step;

        output PSELx;
        output PENABLE;
        output PWRITE;
        output PADDR;
        output PWDATA;
        output PSTRB;

        input PRDATA;
        input PREADY;
        input PSLVERR;

    endclocking


    // Clocking block used by the monitor
    clocking mon_cb @(posedge PCLK);

        default input #1step output #1step;

        input PSELx;
        input PENABLE;
        input PWRITE;
        input PADDR;
        input PWDATA;
        input PSTRB;

        input PRDATA;
        input PREADY;
        input PSLVERR;

    endclocking


    // Modports for driver and monitor access
    modport DRIVER (
        clocking cb,
        input PRESETn
    );

    modport MONITOR (
        clocking mon_cb,
        input PRESETn
    );
*/
endinterface
