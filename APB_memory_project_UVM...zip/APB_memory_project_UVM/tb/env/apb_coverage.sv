class apb_coverage extends uvm_subscriber #(apb_seq_item);
  `uvm_component_utils(apb_coverage)

  apb_seq_item tr;

  // ============================================================
  // Covergroup 1: Basic signals
  // ============================================================
  covergroup cg_basic;
    option.per_instance = 1;

    cp_write : coverpoint tr.write {
      bins read  = {1'b0};
      bins write = {1'b1};
    }

    cp_pslverr : coverpoint tr.pslverr {
      bins no_err = {1'b0};
      bins err    = {1'b1};
    }

    cp_addr : coverpoint tr.addr {
      bins low  = {[32'h0000_0000 : 32'h0000_00FF]};
      bins mid  = {[32'h0000_0100 : 32'h0000_FF00]};
      bins high = {[32'h0000_FF00 : 32'h0000_FFF8]};
      bins oob  = {[32'h0001_0000 : 32'hFFFF_FFFF]};
    }

    cp_align : coverpoint (tr.addr % 8) {
      bins aligned    = {0};
      bins misaligned = {[1:7]};
    }

    cp_strb : coverpoint tr.strb {
      bins all_ff  = {8'hFF};
      bins all_00  = {8'h00};
      bins byte0   = {8'h01};
      bins byte7   = {8'h80};
      bins low32   = {8'h0F};
      bins high32  = {8'hF0};
      bins others  = default;
    }

    cx_write_err : cross cp_write, cp_pslverr;
  endgroup

  // ============================================================
  // Covergroup 2: PSTRB all 256 combos
  // ============================================================
  covergroup cg_pstrb;
    option.per_instance = 1;

    cp_strb_all : coverpoint tr.strb {
      bins all_256[] = {[8'h00 : 8'hFF]};
    }
  endgroup

  // ============================================================
  // Covergroup 3: Cross coverage
  // ============================================================
  covergroup cg_cross;
    option.per_instance = 1;

    cp_addr_type : coverpoint tr.addr {
      bins low  = {[32'h0000_0000 : 32'h0000_FF00]};
      bins high = {[32'h0000_FF00 : 32'h0000_FFF8]};
      bins oob  = {[32'h0001_0000 : 32'hFFFF_FFFF]};
    }

    cp_align_type : coverpoint (tr.addr % 8) {
      bins aligned    = {0};
      bins misaligned = {[1:7]};
    }

    cp_strb_type : coverpoint tr.strb {
      bins all_ff  = {8'hFF};
      bins all_00  = {8'h00};
      bins partial = default;
    }

    cp_pslverr_type : coverpoint tr.pslverr {
      bins no_err = {1'b0};
      bins err    = {1'b1};
    }

    cp_write_type : coverpoint tr.write {
      bins read  = {1'b0};
      bins write = {1'b1};
    }

    cx_addr_align : cross cp_addr_type, cp_align_type;
    cx_strb_err   : cross cp_strb_type, cp_pslverr_type;
    cx_align_err  : cross cp_align_type, cp_pslverr_type;
    cx_write_strb : cross cp_write_type, cp_strb_type;
  endgroup

  // ============================================================
  // Constructor
  // ============================================================
  function new(string name, uvm_component parent);
    super.new(name, parent);
    cg_basic = new();
    cg_pstrb = new();
    cg_cross = new();
  endfunction

  // ============================================================
  // write() ? monitor se data aata hai
  // ============================================================
  virtual function void write(apb_seq_item t);
    tr = t;
    cg_basic.sample();
    cg_pstrb.sample();
    cg_cross.sample();
  endfunction

endclass
