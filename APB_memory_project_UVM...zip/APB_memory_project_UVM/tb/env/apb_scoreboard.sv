class apb_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(apb_scoreboard)

  uvm_analysis_imp #(apb_seq_item, apb_scoreboard) item_collected_export;

  // ---- Reference memory ----
  logic [63:0] ref_mem [0:8191];

  // ---- Counters ----
  int total_txn   = 0;
  int write_txn   = 0;
  int read_txn    = 0;
  int pass_count  = 0;
  int fail_count  = 0;
  int err_count   = 0;
  int x_count     = 0;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    item_collected_export = new("item_collected_export", this);
  endfunction

  virtual function void write(apb_seq_item tr);

    int addr_idx = tr.addr[15:3];
    bit is_oob = (tr.addr > 32'h0000_FFFF);

    total_txn++;

    if (tr.write == 1'b1) begin
      write_txn++;
      if (tr.pslverr == 1'b1 || is_oob) begin
        err_count++;
      end
      else begin
        for (int i = 0; i < 8; i++) begin
          if (tr.strb[i] == 1'b1)
            ref_mem[addr_idx][8*i +: 8] = tr.wdata[8*i +: 8];
        end
      end
    end
    else begin
      read_txn++;
      if (tr.pslverr == 1'b1 || is_oob) begin
        err_count++;
      end
      else if ($isunknown(ref_mem[addr_idx]) || $isunknown(tr.rdata)) begin
        x_count++;
      end
      else if (ref_mem[addr_idx] == tr.rdata) begin
        pass_count++;
      end
      else begin
        fail_count++;
        `uvm_error("SCB", $sformatf("MISMATCH: addr=%0h exp=%0h got=%0h",
                  tr.addr, ref_mem[addr_idx], tr.rdata))
      end
    end
  endfunction

  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info("SCB", "===============================================", UVM_NONE)
    `uvm_info("SCB", "        SCOREBOARD FINAL REPORT                ", UVM_NONE)
    `uvm_info("SCB", "===============================================", UVM_NONE)
    `uvm_info("SCB", $sformatf(" Total transactions : %0d", total_txn), UVM_NONE)
    `uvm_info("SCB", $sformatf("   Writes           : %0d", write_txn), UVM_NONE)
    `uvm_info("SCB", $sformatf("   Reads            : %0d", read_txn), UVM_NONE)
    `uvm_info("SCB", "-----------------------------------------------", UVM_NONE)
    `uvm_info("SCB", $sformatf(" PASS               : %0d", pass_count), UVM_NONE)
    `uvm_info("SCB", $sformatf(" FAIL               : %0d", fail_count), UVM_NONE)
    `uvm_info("SCB", $sformatf(" PSLVERR (skipped)  : %0d", err_count), UVM_NONE)
    `uvm_info("SCB", $sformatf(" X/Z (skipped)      : %0d", x_count), UVM_NONE)
    `uvm_info("SCB", "===============================================", UVM_NONE)
  endfunction

  function void check_phase(uvm_phase phase);
    super.check_phase(phase);
    if (fail_count > 0)
      `uvm_error("SCB", $sformatf("TEST FAILED: %0d mismatches", fail_count))
    if (total_txn == 0)
      `uvm_error("SCB", "TEST FAILED: No transactions!")
  endfunction

endclass
