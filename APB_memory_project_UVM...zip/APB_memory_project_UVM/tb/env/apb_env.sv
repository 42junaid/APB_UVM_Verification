class apb_env extends uvm_env;
  `uvm_component_utils(apb_env)

  apb_agent      agent;
  apb_scoreboard scoreboard;
  apb_coverage   coverage;      // ? Coverage component

  function new(string path = "apb_env", uvm_component parent = null);
    super.new(path, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agent      = apb_agent::type_id::create("agent", this);
    scoreboard = apb_scoreboard::type_id::create("scoreboard", this);
    coverage   = apb_coverage::type_id::create("coverage", this);   // ?
    `uvm_info("ENV", "Build phase executed", UVM_LOW)
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    // Monitor ? Scoreboard
    agent.monitor.item_collected_port.connect(scoreboard.item_collected_export);
    // Monitor ? Coverage
    agent.monitor.item_collected_port.connect(coverage.analysis_export);   // ?
    `uvm_info("ENV", "Monitor connected to Scoreboard and Coverage", UVM_LOW)
  endfunction

endclass
